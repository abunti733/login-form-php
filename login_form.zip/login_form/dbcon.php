<?php

$db_con=mysqli_connect("localhost","root","","class_3");
if($db_con){
    echo "yes";
}else{
    echo "no";
}



?>